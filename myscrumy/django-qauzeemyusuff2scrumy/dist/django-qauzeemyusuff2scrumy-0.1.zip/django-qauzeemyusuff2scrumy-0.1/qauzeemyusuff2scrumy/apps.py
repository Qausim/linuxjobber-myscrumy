from django.apps import AppConfig


class Qauzeemyusuff2ScrumyConfig(AppConfig):
    name = 'qauzeemyusuff2scrumy'
